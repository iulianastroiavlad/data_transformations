import pandas as pd
import df2rdf.mapping_engine as me


def to_rdf(cls, mapping=None, skip_errors=False):
    if mapping:
        mapping = me.load_mapping(mapping)
        # print("Thanks for the mapping, but the mapping engine is under development!")
        return me.map_pandas_df_to_rdf(cls, mapping, skip_errors)
    else:
        # print("Direct mapping!")
        # direct mapping, check how to integrate rdb2rdf here
        # pass
        raise Exception("No mapping provided.")


pd.DataFrame.to_rdf = to_rdf
