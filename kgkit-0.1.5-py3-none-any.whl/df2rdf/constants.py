ALLOWED_TERM_TYPES = {
    "Literal"
}
