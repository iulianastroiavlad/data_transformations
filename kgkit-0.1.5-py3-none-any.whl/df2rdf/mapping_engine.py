import rdflib
from typing import Union
import df2rdf.constants as constants
import json
import pandas as pd
from typing import Dict
import urllib.parse
from string import Formatter
from re import sub, compile


def valid_mapping(df, mapping) -> bool:
    """
    :param mapping:
    :return:
    """
    # for now we only support Literal for destination_type but in future we will support all types specified here:
    # http://rdflib.readthedocs.io/en/stable/rdf_terms.html#python-support
    for m in mapping["mapping"]:
        # 1. validate if all the source_value_column names are actually in the dataframe

        # 2. validate the mapping syntax
        # A mapping must have source_type and destination_type
        if ("destination_type" not in m and "destination_type_column" not in m) or ("source_type" not in m and "source_type_column" not in m):
            raise Exception("A mapping must have source_type and destination_type")

        if "property" not in m and "property_column" not in m:
            raise Exception("A mapping must have either property or property_type")

        # when destination_lang is present, allowed destination_type == Literal
        if "destination_lang" in m:
            if m["destination_type"] != "Literal":
                raise Exception("The destination_type must be 'Literal' for the mapping: ", str(m))

        if "destination_lang_column" in m and "destination_lang" in m:
            raise Exception(
                "destination_lang and destination_lang_column can't be present together for the mapping: ", str(m)
            )

        # both column name and column expression should not be present
        if "source_value_column" in m and "source_value_column_expression" in m:
            raise Exception("A mapping can have either source_value_column or source_value_column_expression: ", str(m))
        if "destination_value_column" in m and "destination_value_column_expression" in m:
            raise Exception(
                "A mapping can have either destination_value_column or destination_value_column_expression:", str(m)
            )

        # one of column name or column expression should be present
        if "source_value_column" not in m and "source_value_column_expression" not in m:
            raise Exception("A mapping can have either source_value_column or source_value_column_expression:", str(m))
        if "destination_value_column" not in m and "destination_value_column_expression" not in m:
            raise Exception(
                "A mapping can have either destination_value_column or destination_value_column_expression:", str(m))

        # both source_type and source_type_column should not be present
        if "source_type" in m and "source_type_column" in m:
            raise Exception("A mapping can have either source_type or source_type_column: ", str(m))

        # both destination_type and destination_type_column should not be present
        if "destination_type" in m and "destination_type_column" in m:
            raise Exception("A mapping can have either destination_type or destination_type_column: ", str(m))

        # both property and property_column should not be present
        if "property" in m and "property_column" in m:
            raise Exception("A mapping can have either property or property_column: ", str(m))

    # 3. validate the data types specified in the destination_type for data properties
    return True


def normalize_col_val(mapping, v_type, val, is_resource, data_type=None, lang=None) -> Union[rdflib.term.URIRef,
                                                                             rdflib.term.Literal, None]:
    data_uri = mapping["base_data_uri"]
    data_ns = rdflib.Namespace(data_uri)
    if not is_resource and v_type not in constants.ALLOWED_TERM_TYPES:
        # define a list of exceptions and replace this generic exception by a specific one
        raise Exception("Data type {} is not supported!".format(v_type))
    if is_resource:
        res = data_ns[urllib.parse.quote_plus(val)]
    else:

        # default string type
        if not data_type and not isinstance(val, str):
            val = str(val)
        elif data_type == "str" and not isinstance(val, str):
            val = str(val)
        elif data_type == "bool" and not isinstance(val, bool):
            val = True if val == "True" or val == "true" else False
        elif data_type == "float" and not isinstance(val, float):
            val = float(val)
        elif data_type == "int" and not isinstance(val, int):
            try:
                val = int(val)
            except ValueError:
                # ValueError: invalid literal for int() with base 10: '0.0'
                val = int(eval(val))

        if not val and isinstance(val, str):  # empty string case
            return None

        res = rdflib.term.Literal(val, lang=lang) if lang else rdflib.term.Literal(val)

    return res


def normalize_ontology_term(mapping, term) -> rdflib.term.URIRef:
    base_ontology_uri = mapping["base_ontology_uri"]
    base_ontology_ns = rdflib.Namespace(base_ontology_uri)

    prefix_uris = mapping["prefixes"]
    prefix_nss = {}
    for prefix, uri in prefix_uris.items():
        prefix_nss[prefix] = rdflib.Namespace(uri)

    term_tokens = term.split(":")
    prefix_token = None
    term_token = None
    if len(term_tokens) == 1 and term_tokens[0]:
        default = True
        term_token = term_tokens[0]
    elif len(term_tokens) == 2 and not term_tokens[0] and term_tokens[1]:
        default = True
        term_token = term_tokens[1]
    elif len(term_tokens) == 2 and term_tokens[0] and term_tokens[1]:
        default = False
        term_token = term_tokens[1]
        prefix_token = term_tokens[0]
    else:
        # define a list of exceptions and replace this generic exception by a specific one
        raise Exception("Invalid term {}.".format(term))

    if default:
        return base_ontology_ns[term_token]
    else:
        if prefix_token not in prefix_nss:
            # define a list of exceptions and replace this generic exception by a specific one
            raise Exception("Prefix {} is not specified in the mapping.".format(prefix_token))
        return prefix_nss[prefix_token][term_token]


def value_is_resource(v_type) -> bool:
    return v_type not in constants.ALLOWED_TERM_TYPES


def map_pandas_df_to_rdf(df, mapping, skip_errors) -> Union[rdflib.Graph, None, bool]:
    if valid_mapping(df, mapping):
        graph = rdflib.Graph()
        for index, row in df.iterrows():
            # print("Row:")
            # print("######################")
            # print(row)

            for m in mapping["mapping"]:
                # print("---------")
                # print("Mapping:", str(m))
                source_type = None  # to make PEP8 stop complaining
                if "source_type" in m:
                    source_type = m["source_type"]
                elif "source_type_column" in m:
                    source_type = build_explode_val_list(
                        None, row[m["source_type_column"]], None, False, None, m, row
                    )[0]

                source_val_delim = None
                source_explode = False
                # print("********************** in source")
                if "source_explode" in m and m["source_explode"] is True:
                    if "source_explode_delimiter" not in m:
                        raise Exception(
                            "source_explode_delimiter must be present when source_explode is present. Mapping: ", str(m)
                        )

                    source_val_delim = m["source_explode_delimiter"]
                    source_explode = True

                if "source_value_column" in m:
                    source_col = m["source_value_column"]
                    source_val_list = build_explode_val_list(
                        source_val_delim, row[source_col], source_explode, False, None, m, row
                    )
                elif "source_value_column_expression" in m:
                    column_expression = m["source_value_column_expression"]
                    source_val_list = build_explode_val_list(
                        source_val_delim, None,
                        source_explode, True, column_expression, m,
                        row
                    )
                else:
                    raise Exception(
                        "Can't find source_value_column or source_value_column_expression in this mapping: ", str(m)
                    )
                if source_val_list is None:
                    # print("continuing:", str(m))
                    continue
                source_val_position = 0
                for source_val in source_val_list:
                    # print("source_val:", source_val)
                    if pd.isnull(source_val) or source_val is None:
                        continue
                    subj = normalize_col_val(mapping, source_type, source_val, is_resource=True)
                    subj_type = normalize_ontology_term(mapping, source_type)

                    prop = None  # to make PEP8 stop complaining
                    if "property" in m:
                        prop = m["property"]
                    elif "property_column" in m:
                        prop = build_explode_val_list(
                            None, row[m["property_column"]], None, False, None, m, row
                        )[0]

                    pred = normalize_ontology_term(mapping, prop)

                    process_destination_and_create_triples(
                        graph, m, mapping, pred, row, subj, subj_type,
                        source_val_position, source_explode, skip_errors
                    )
                    source_val_position += 1
            # print("######################")
        return graph
    else:
        raise Exception("Invalid mapping.")


def build_explode_val_list(delim, val, has_explode, has_expression, column_expression, m, row):
    # val is None when has_expression is true
    # print("delim:", delim)
    # print("val:", val)
    # print("has_explode:", has_explode)
    # print("has_expression:", has_expression)
    # print("column_expression:", column_expression)
    field_references = []
    if has_expression is True:
        field_references = [fname for _, fname, _, _ in Formatter().parse(column_expression) if fname]
        # for field in field_references:

        # val = explode_expression.format_map(row.to_dict())
        if len(field_references) == 0:
            raise Exception(
                "An expression must have at least one column. Mapping: ", str(m)
            )

    if has_explode is True and has_expression is True:
        if len(field_references) > 1:
            raise Exception(
                "Only 1 column allowed in an expression when explode and expression "
                "present together for a source or destination. Mapping: ", str(m)
            )

    # m["source_value_column_expression"].format_map(row.to_dict())

    ret = []
    if has_expression is True:
        if has_explode is True:
            col_name = field_references[0]  # only 1 column allowed for now in an expression when explode is present
            col_val = row[col_name]
            # print("col_val", col_val)
            if pd.isnull(col_val) or (not col_val and isinstance(col_val, str)):
                # print("############################## Skipping")
                return None
            val_list = [x.strip() for x in str(col_val).split(delim)]
            for vv in val_list:
                vd = {col_name: vv}
                v = column_expression.format_map(vd)
                ret.append(v)
        else:
            for field in field_references:
                if pd.isnull(row[field]):
                    return None
            ret = [column_expression.format_map(row.to_dict())]
    else:
        if pd.isnull(val) or (not val and isinstance(val, str)):
            # print("############################## Skipping")
            return None

        ret = [x.strip() for x in str(val).split(delim)] if has_explode is True else [val]

    # print("Return:", ret)
    return None if len(ret) == 0 else ret


_lang_tag_regex = compile('^[a-zA-Z]+(?:-[a-zA-Z0-9]+)*$')


def _is_valid_langtag(tag):
    return bool(_lang_tag_regex.match(tag))


def process_destination_and_create_triples(
        graph, m, mapping, pred, row, subj, subj_type, source_val_position, source_explode, skip_errors
):
    # print("********************** in destination")
    dest_type = None  # to make PEP8 stop complaining
    if "destination_type" in m:
        dest_type = m["destination_type"]
    elif "destination_type_column" in m:
        dest_type = build_explode_val_list(
            None, row[m["destination_type_column"]], None, False, None, m, row
        )[0]

    dest_lang_column = None
    dest_lang = None
    if "destination_lang_column" in m:
        dest_lang_column = m["destination_lang_column"]
        dest_lang = row[dest_lang_column].lower()
        if not _is_valid_langtag(dest_lang):
            dest_lang = None

    if "destination_lang" in m:
        dest_lang = m["destination_lang"]
    data_type = None
    if "destination_data_type" in m:
        data_type = m["destination_data_type"]
    dest_val_is_res = value_is_resource(dest_type)
    dest_val_delim = None
    dest_explode = False
    if "destination_explode" in m and m["destination_explode"] is True:
        if "destination_explode_delimiter" not in m:
            raise Exception(
                "destination_explode_delimiter must be present when destination_explode is present. Mapping: ", str(m)
            )

        dest_val_delim = m["destination_explode_delimiter"]
        dest_explode = True

    dest_val_list = None
    if "destination_value_column" in m:
        dest_col = m["destination_value_column"]
        # dest_val_list = build_explode_val_list(dest_val_delim, row[dest_col])

        # If skip_errors is True, do not throw errors if there are one or more properties missing in the data
        # but need to be present as per the mapping
        if skip_errors:
            if dest_col in row:
                dest_val_list = build_explode_val_list(
                    dest_val_delim, row[dest_col], dest_explode, False, None, m, row
                )
        else:
            dest_val_list = build_explode_val_list(
                dest_val_delim, row[dest_col], dest_explode, False, None, m, row
            )

    elif "destination_value_column_expression" in m:

        column_expression = m["destination_value_column_expression"]
        dest_val_list = build_explode_val_list(
            dest_val_delim, None,
            dest_explode, True, column_expression, m,
            row
        )

        # dest_val_list = build_explode_val_list(
        #     dest_val_delim, m["destination_value_column_expression"].format_map(row.to_dict())
        # )
    else:
        raise Exception(
            "Can't find destination_value_column or destination_value_column_expression in this mapping: ",
            str(m)
        )
    # print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~dest val list", dest_val_list)
    if dest_val_list is None:
        # print("............................... NOT CREATING TRIPLES")
        return
    if source_explode is True and dest_explode is True and m["source_destination_explode_positional"] is True:
        if len(dest_val_list) < source_val_position:
            # return graph
            return
        dest_val_list = [dest_val_list[source_val_position]]
    for dest_val in dest_val_list:
        if pd.isnull(dest_val):
            continue
        obj = normalize_col_val(
            mapping,
            dest_type,
            dest_val,
            is_resource=dest_val_is_res,
            lang=dest_lang,
            data_type=data_type
        )
        if obj is None:
            continue
        # print("Adding triple", (subj, pred, obj))
        # print("Adding triple", (subj, rdflib.namespace.RDF.type, subj_type))
        graph.add((subj, pred, obj))

        graph.add((subj, rdflib.namespace.RDF.type, subj_type))
        if dest_val_is_res:
            obj_type = normalize_ontology_term(mapping, dest_type)
            graph.add((obj, rdflib.namespace.RDF.type, obj_type))
            # print("Adding triple", (obj, rdflib.namespace.RDF.type, obj_type))
    # return graph


def load_mapping(m) -> Dict[str, str]:
    if isinstance(m, str):
        with open(m) as f:
            return json.load(f)
    elif isinstance(m, dict):
        return m
    else:
        raise Exception("Invalid mapping.")
