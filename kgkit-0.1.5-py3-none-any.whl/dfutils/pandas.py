import pandas as pd
import numpy as np


# adapted from https://stackoverflow.com/a/40449726/2263844
def explode(df, lst_cols, fill_value=''):
    # make sure `lst_cols` is a list
    if lst_cols and not isinstance(lst_cols, list):
        lst_cols = [lst_cols]
    # all columns except `lst_cols`
    idx_cols = df.columns.difference(lst_cols)

    # calculate lengths of lists
    lens = df[lst_cols[0]].str.len()

    if (lens > 0).all():
        # ALL lists in cells aren't empty
        return pd.DataFrame({
            col:np.repeat(df[col].values, df[lst_cols[0]].str.len())
            for col in idx_cols
        }).assign(**{col:np.concatenate(df[col].values) for col in lst_cols}) \
          .loc[:, df.columns]
    else:
        # at least one list in cells is empty
        return pd.DataFrame({
            col:np.repeat(df[col].values, df[lst_cols[0]].str.len())
            for col in idx_cols
        }).assign(**{col:np.concatenate(df[col].values) for col in lst_cols}) \
          .append(df.loc[lens==0, idx_cols]).fillna(fill_value) \
          .loc[:, df.columns]


def df_colum_split_tolist(df, col_name, delim):
    kwargs = {col_name: df[col_name].str.split(delim)}
    df = df.assign(**kwargs)

    def lstrip(x):
        if not isinstance(x, list):
            return None
        ll = [v.strip() for v in x]
        # ugly but return ll gives np shape error which is probably a bug in pandas
        return delim.join(ll)

    df[col_name] = df.apply(lambda x: lstrip(x[col_name]), axis=1)
    df[col_name] = df[col_name].replace(np.nan, '', regex=True)
    kwargs_fin = {col_name: df[col_name].str.split(delim)}
    return df.assign(**kwargs_fin)


def explode_column(df, col_name, delim, fill_value=''):
    df = df_colum_split_tolist(df, col_name, delim)
    return explode(df, col_name, fill_value)


def explode_single_col(df, col_name, delim, fill_value=''):
    return explode_column(df, col_name, delim, fill_value)
